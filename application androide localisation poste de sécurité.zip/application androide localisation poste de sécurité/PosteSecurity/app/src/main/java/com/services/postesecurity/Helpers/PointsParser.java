package com.services.postesecurity.Helpers;

import android.content.Context;
import android.graphics.Color;
import android.os.AsyncTask;
import android.util.Log;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class PointsParser extends AsyncTask<String , Integer, List<List<HashMap<String, String>>>> {
    TaskLoadedCallback taskLoadedCallback;
    String direction = "driving";

    // Method for parsing the roads on the map

    public PointsParser (Context context, String direction){
        this.taskLoadedCallback = (TaskLoadedCallback) context;
        this.direction = direction;
    }
    @Override
    protected List<List<HashMap<String, String>>> doInBackground(String... jsonData) {
        JSONObject jsonObject;
        List<List<HashMap<String, String>>> routes = null;
        try {
            jsonObject = new JSONObject(jsonData[0]);
            Log.d("Log parsing data", "JsonData"+jsonData[0].toString());
            DataParser dataParser = new DataParser();
            Log.d("Data Parser", "Parsering" +dataParser.toString());

            // Starts parsing data
            routes = dataParser.parse(jsonObject);
            Log.d("MyLog", "Executing roads" +routes.toString());

        }catch (Exception e){
            e.printStackTrace();
            Log.d("Exception!","Generated Exception "+ e.toString());

        }
        return routes;
    }

    @Override
    protected void onPostExecute(List<List<HashMap<String, String>>> results) {
        ArrayList<LatLng> points;
        PolylineOptions polylineOptions = null;

        //Traversing all the roads
        for (int i = 0; i<results.size(); i++){
           points = new ArrayList<>();
           polylineOptions = new PolylineOptions();

           // Fetching the i_road to n_roads
            List<HashMap<String, String>> path = results.get(i);
            //All the points to the roads
            for (int j =0; j<path.size(); j++){
                HashMap<String, String> point = path.get(i);
                double lat =Double.parseDouble(point.get("lat"));
                double lng =Double.parseDouble(point.get("lng"));
                LatLng position = new LatLng(lat,lng);
                points.add(position);

            }
            // Adding all the points in the roads to LineOptions
            polylineOptions.addAll(points);
            if(direction.equalsIgnoreCase("walking")){
                polylineOptions.width(10);
                polylineOptions.color(Color.GRAY);
            }else {
                polylineOptions.width(20);
                polylineOptions.color(Color.BLUE);
            }
            Log.d("MyLog", "OnPostExecute for the polyLineOptions");

        }

        // Drawing the polyline in the Google Map for the i_road to n_roads

        if (polylineOptions !=null){
            taskLoadedCallback.onTaskDone(polylineOptions);

        }else {
            Log.d("Mylog", "Without polylines");
        }
    }
}